# ShadowScan v2

AI-assisted Shadow IT monitoring platform.

## Features
- **Real-time Monitoring**: Browser extension detects domain navigation and triggers risk analysis.
- **AI Risk Engine**: Multi-factor risk scoring using VirusTotal, Shodan, and Category-based heuristics.
- **Security Dashboard**: Stats, charts, and tables to visualize organizational SaaS usage.
- **Alerting**: Real-time Socket.IO alerts + Email & Slack notifications for high-risk tools.
- **Policies**: Admin-defined rules to block categories or specific domains.
- **PDF Reporting**: Executive summaries of security posture.

## Tech Stack
- **Frontend**: Next.js 14, Tailwind CSS, Recharts, Zustand.
- **Backend**: Node.js, Express, Prisma ORM, Socket.IO.
- **Database**: PostgreSQL.
- **Extension**: Chrome Manifest V3.

## How to Run

1. **Clone the repo**
2. **Setup environment variables**
   ```bash
   cp .env.example .env
   ```
   Fill in your API keys (VirusTotal, Shodan) and SMTP details.

3. **Start with Docker**
   ```bash
   docker-compose up --build
   ```

4. **Initialize Database**
   ```bash
   docker-compose exec api npm run prisma:migrate
   docker-compose exec api npm run prisma:seed
   ```

5. **Access the platform**
   - Dashboard: `http://localhost:3000`
   - API: `http://localhost:5000`
   - Default Login: `admin@demo.com` / `Demo@1234`

## License
MIT
