#!/bin/sh

# Wait for database to be ready
echo "Waiting for postgres..."
while ! nc -z postgres 5432; do
  sleep 1
done

# Run migrations & generate
npx prisma generate
npx prisma migrate deploy

# Start server
npm run start
