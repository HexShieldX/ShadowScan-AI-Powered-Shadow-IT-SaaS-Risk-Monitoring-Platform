const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  // Create Demo Company
  const company = await prisma.company.create({
    data: { name: 'Demo Company' },
  });

  // Create Users
  const hashedPassword = await bcrypt.hash('Demo@1234', 10);
  
  const admin = await prisma.user.create({
    data: {
      email: 'admin@demo.com',
      password: hashedPassword,
      name: 'Admin User',
      role: 'ADMIN',
      companyId: company.id,
    },
  });

  const employee = await prisma.user.create({
    data: {
      email: 'employee@demo.com',
      password: hashedPassword,
      name: 'Employee User',
      role: 'EMPLOYEE',
      companyId: company.id,
    },
  });

  // Create Sample Tools
  const toolsData = [
    { name: 'Notion', domain: 'notion.so', category: 'PROJECT_MGMT' },
    { name: 'Dropbox', domain: 'dropbox.com', category: 'FILE_SHARING' },
    { name: 'ChatGPT', domain: 'chatgpt.com', category: 'AI_TOOL' },
    { name: 'Telegram', domain: 't.me', category: 'MESSAGING' },
    { name: 'Slack', domain: 'slack.com', category: 'MESSAGING' },
    { name: 'Zoom', domain: 'zoom.us', category: 'VIDEO_CONF' },
    { name: 'Figma', domain: 'figma.com', category: 'PROJECT_MGMT' },
    { name: 'Trello', domain: 'trello.com', category: 'PROJECT_MGMT' },
    { name: 'WeTransfer', domain: 'wetransfer.com', category: 'FILE_SHARING' },
    { name: 'Discord', domain: 'discord.com', category: 'MESSAGING' },
  ];

  for (const tool of toolsData) {
    await prisma.tool.upsert({
      where: { domain: tool.domain },
      update: {},
      create: tool,
    });
  }

  // Create Sample Policies
  await prisma.policy.createMany({
    data: [
      { name: 'Block High Risk File Sharing', rule: 'BLOCK_CATEGORY', value: 'FILE_SHARING', companyId: company.id },
      { name: 'Strict AI Policy', rule: 'BLOCK_CATEGORY', value: 'AI_TOOL', companyId: company.id, isActive: false },
      { name: 'Block Malicious Domain', rule: 'BLOCK_DOMAIN', value: 'malicious-site.com', companyId: company.id },
    ],
  });

  console.log('Seed data created successfully.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
