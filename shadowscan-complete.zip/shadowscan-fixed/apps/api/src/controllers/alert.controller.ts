import { Response, NextFunction } from 'express';
import { PrismaClient } from '@prisma/client';
import { AuthRequest } from '../middleware/auth.middleware';
import { ForbiddenError, NotFoundError } from '../utils/errors';

const prisma = new PrismaClient();

export class AlertController {
  public static async getAlerts(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const { companyId } = req.user!;
      const alerts = await prisma.alert.findMany({
        where: { companyId },
        orderBy: { createdAt: 'desc' },
        include: { scan: true },
      });
      res.status(200).json(alerts);
    } catch (error) {
      next(error);
    }
  }

  public static async markAsRead(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const { companyId } = req.user!;

      const alert = await prisma.alert.findUnique({ where: { id } });
      if (!alert) return next(new NotFoundError('Alert not found'));
      if (alert.companyId !== companyId) return next(new ForbiddenError('Access denied'));

      await prisma.alert.update({ where: { id }, data: { isRead: true } });
      res.status(200).json({ message: 'Alert marked as read' });
    } catch (error) {
      next(error);
    }
  }
}
