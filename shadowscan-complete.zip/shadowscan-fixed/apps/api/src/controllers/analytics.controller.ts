import { Response, NextFunction } from 'express';
import { PrismaClient, Verdict } from '@prisma/client';
import { AuthRequest } from '../middleware/auth.middleware';

const prisma = new PrismaClient();

export class AnalyticsController {
  public static async getOverview(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const { companyId } = req.user!;
      
      const totalScans = await prisma.scan.count({ where: { companyId } });
      const highRisk = await prisma.scan.count({ 
        where: { companyId, verdict: { in: [Verdict.HIGH_RISK, Verdict.BLOCKED] } } 
      });
      const blocked = await prisma.scan.count({ where: { companyId, verdict: Verdict.BLOCKED } });
      const avgRisk = await prisma.scan.aggregate({
        where: { companyId },
        _avg: { riskScore: true }
      });

      res.status(200).json({
        totalScans,
        highRisk,
        blocked,
        avgRiskScore: Math.round(avgRisk._avg.riskScore || 0)
      });
    } catch (error) {
      next(error);
    }
  }

  public static async getRiskTrend(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const { companyId } = req.user!;
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

      const scans = await prisma.scan.findMany({
        where: { companyId, createdAt: { gte: thirtyDaysAgo } },
        select: { createdAt: true, riskScore: true },
        orderBy: { createdAt: 'asc' }
      });

      // Group by date
      const trend = scans.reduce((acc: any, scan) => {
        const date = scan.createdAt.toISOString().split('T')[0];
        if (!acc[date]) acc[date] = { date, count: 0, avgRisk: 0, sumRisk: 0 };
        acc[date].count += 1;
        acc[date].sumRisk += scan.riskScore;
        acc[date].avgRisk = Math.round(acc[date].sumRisk / acc[date].count);
        return acc;
      }, {});

      res.status(200).json(Object.values(trend));
    } catch (error) {
      next(error);
    }
  }

  public static async getCategoryStats(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const { companyId } = req.user!;
      const scans = await prisma.scan.findMany({
        where: { companyId },
        include: { tool: { select: { category: true } } },
      });
      const counts: Record<string, number> = {};
      for (const scan of scans) {
        const cat = scan.tool?.category ?? 'UNKNOWN';
        counts[cat] = (counts[cat] || 0) + 1;
      }
      res.status(200).json(Object.entries(counts).map(([name, value]) => ({ name, value })));
    } catch (error) {
      next(error);
    }
  }
}
