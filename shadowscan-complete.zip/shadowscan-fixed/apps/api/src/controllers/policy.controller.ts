import { Response, NextFunction } from 'express';
import { AuthRequest } from '../middleware/auth.middleware';
import { PolicyService } from '../services/policy.service';

export class PolicyController {
  public static async getPolicies(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const policies = await PolicyService.getCompanyPolicies(req.user!.companyId);
      res.status(200).json(policies);
    } catch (error) {
      next(error);
    }
  }

  public static async createPolicy(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const policy = await PolicyService.createPolicy(req.user!.companyId, req.body);
      res.status(201).json(policy);
    } catch (error) {
      next(error);
    }
  }

  public static async updatePolicy(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const policy = await PolicyService.updatePolicy(req.params.id, req.user!.companyId, req.body);
      res.status(200).json(policy);
    } catch (error) {
      next(error);
    }
  }

  public static async deletePolicy(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      await PolicyService.deletePolicy(req.params.id, req.user!.companyId);
      res.status(204).send();
    } catch (error) {
      next(error);
    }
  }
}
