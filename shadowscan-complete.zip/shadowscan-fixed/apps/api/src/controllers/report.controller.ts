import { Response, NextFunction } from 'express';
import { AuthRequest } from '../middleware/auth.middleware';
import { ReportService } from '../services/report.service';

export class ReportController {
  public static async generateReport(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      await ReportService.generateCompanyReport(req.user!.companyId, res);
    } catch (error) {
      next(error);
    }
  }
}
