import { Response, NextFunction } from 'express';
import { PrismaClient, Category, Severity } from '@prisma/client';
import { AuthRequest } from '../middleware/auth.middleware';
import { RiskEngineService } from '../services/risk-engine.service';
import { AlertService } from '../services/alert.service';
import { emitToCompany } from '../utils/socket';
import { logger } from '../utils/logger';

const prisma = new PrismaClient();

export class ScanController {
  public static async createScan(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const rawDomain = req.body.domain;
      const domain = RiskEngineService.cleanDomain(rawDomain);
      const { id: userId, companyId } = req.user!;

      // 1. Identify tool or create new "Unknown" entry
      let tool = await prisma.tool.findUnique({ where: { domain } });
      const category = tool?.category || Category.UNKNOWN;

      // 2. Fetch policies
      const policies = await prisma.policy.findMany({ where: { companyId, isActive: true } });

      // 3. Run Analysis
      const analysis = await RiskEngineService.analyze(domain, category, policies);

      // 4. Save Scan Result
      const scan = await prisma.scan.create({
        data: {
          domain,
          toolId: tool?.id,
          userId,
          companyId,
          riskScore: analysis.score,
          verdict: analysis.verdict,
          riskBreakdown: analysis.breakdown as any,
          virusTotalData: analysis.vtData as any,
          shodanData: analysis.shodanData as any,
          whoisData: analysis.whoisData as any,
        },
        include: { tool: true, user: { select: { name: true, email: true } } }
      });

      // 5. Real-time update & Alerts (Wrapped to prevent request failure)
      try {
        emitToCompany(companyId, 'new-scan', scan);

        if (analysis.verdict === 'HIGH_RISK' || analysis.verdict === 'BLOCKED') {
          await AlertService.createAlert({
            message: `High risk tool detected: ${domain} (Score: ${analysis.score})`,
            severity: analysis.score > 80 ? Severity.CRITICAL : Severity.HIGH,
            userId,
            companyId,
            scanId: scan.id,
          }).catch(err => logger.error(`Alert creation failed: ${err.message}`));
        }
      } catch (err) {
        logger.error(`Post-scan background tasks failed: ${err}`);
      }

      res.status(201).json(scan);
    } catch (error: any) {
      logger.error(`Scan creation failed: ${error.message}`);
      next(error);
    }
  }

  public static async getScans(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const { companyId } = req.user!;
      const scans = await prisma.scan.findMany({
        where: { companyId },
        include: { tool: true, user: { select: { name: true } } },
        orderBy: { createdAt: 'desc' },
        take: 100,
      });
      res.status(200).json(scans);
    } catch (error) {
      next(error);
    }
  }
}
