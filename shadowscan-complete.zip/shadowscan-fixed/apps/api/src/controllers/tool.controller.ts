import { Request, Response, NextFunction } from 'express';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export class ToolController {
  public static async getTools(req: Request, res: Response, next: NextFunction) {
    try {
      const tools = await prisma.tool.findMany({
        orderBy: { name: 'asc' }
      });
      res.status(200).json(tools);
    } catch (error) {
      next(error);
    }
  }

  public static async getToolByDomain(req: Request, res: Response, next: NextFunction) {
    try {
      const { domain } = req.params;
      const tool = await prisma.tool.findUnique({
        where: { domain }
      });
      res.status(200).json(tool);
    } catch (error) {
      next(error);
    }
  }
}
