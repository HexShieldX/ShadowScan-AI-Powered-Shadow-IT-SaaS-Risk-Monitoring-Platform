import { Response, NextFunction } from 'express';
import { PrismaClient } from '@prisma/client';
import { AuthRequest } from '../middleware/auth.middleware';

const prisma = new PrismaClient();

export class UserController {
  public static async getMe(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const user = await prisma.user.findUnique({
        where: { id: req.user!.id },
        select: {
          id: true,
          email: true,
          name: true,
          role: true,
          companyId: true,
          createdAt: true,
        },
      });
      res.status(200).json(user);
    } catch (error) {
      next(error);
    }
  }

  public static async updateProfile(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const { name } = req.body;
      const user = await prisma.user.update({
        where: { id: req.user!.id },
        data: { name },
      });
      res.status(200).json(user);
    } catch (error) {
      next(error);
    }
  }
}
