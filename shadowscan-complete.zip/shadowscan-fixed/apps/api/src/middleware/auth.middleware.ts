import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { UnauthorizedError } from '../utils/errors';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export interface AuthRequest extends Request {
  user?: {
    id: string;
    email: string;
    role: string;
    companyId: string;
  };
}

export const authMiddleware = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const authHeader = req.headers.authorization;
    const token = authHeader?.startsWith('Bearer ') ? authHeader.split(' ')[1] : null;

    if (!token) {
      return next(new UnauthorizedError('No token provided'));
    }

    const secret = process.env.JWT_SECRET || 'fallback_secret';
    let decoded: any;
    
    try {
      decoded = jwt.verify(token, secret);
    } catch (err) {
      return next(new UnauthorizedError('Token verification failed'));
    }

    const user = await prisma.user.findUnique({
      where: { id: decoded.id },
      select: { id: true, email: true, role: true, companyId: true },
    });

    if (!user) {
      return next(new UnauthorizedError('Account not found'));
    }

    req.user = user as any;
    next();
  } catch (error) {
    next(new UnauthorizedError('Authentication failed'));
  }
};
