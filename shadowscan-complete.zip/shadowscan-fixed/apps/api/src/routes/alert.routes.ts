import { Router } from 'express';
import { AlertController } from '../controllers/alert.controller';
import { authMiddleware } from '../middleware/auth.middleware';

const router = Router();

router.use(authMiddleware as any);

router.get('/', AlertController.getAlerts as any);
router.patch('/:id/read', AlertController.markAsRead as any);

export default router;
