import { Router } from 'express';
import { AnalyticsController } from '../controllers/analytics.controller';
import { authMiddleware } from '../middleware/auth.middleware';

const router = Router();

router.use(authMiddleware as any);

router.get('/overview', AnalyticsController.getOverview as any);
router.get('/risk-trend', AnalyticsController.getRiskTrend as any);
router.get('/categories', AnalyticsController.getCategoryStats as any);

export default router;
