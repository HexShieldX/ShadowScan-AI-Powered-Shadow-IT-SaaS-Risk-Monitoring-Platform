import { Router } from 'express';
import { PolicyController } from '../controllers/policy.controller';
import { authMiddleware } from '../middleware/auth.middleware';
import { rbacMiddleware } from '../middleware/rbac.middleware';
import { Role } from '@prisma/client';

const router = Router();

router.use(authMiddleware as any);

router.get('/', PolicyController.getPolicies as any);
router.post('/', rbacMiddleware([Role.ADMIN]), PolicyController.createPolicy as any);
router.patch('/:id', rbacMiddleware([Role.ADMIN]), PolicyController.updatePolicy as any);
router.delete('/:id', rbacMiddleware([Role.ADMIN]), PolicyController.deletePolicy as any);

export default router;
