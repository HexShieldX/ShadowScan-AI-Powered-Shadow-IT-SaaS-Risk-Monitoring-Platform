import { Router } from 'express';
import { ScanController } from '../controllers/scan.controller';
import { authMiddleware } from '../middleware/auth.middleware';
import { validate } from '../middleware/validate.middleware';
import { z } from 'zod';

const router = Router();

const scanSchema = z.object({
  body: z.object({
    domain: z.string().regex(/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9][a-z0-9-]{0,61}[a-z0-9]$/i, 'Invalid domain format'),
  }),
});

router.use(authMiddleware as any);

router.post('/', validate(scanSchema), ScanController.createScan as any);
router.get('/', ScanController.getScans as any);

export default router;
