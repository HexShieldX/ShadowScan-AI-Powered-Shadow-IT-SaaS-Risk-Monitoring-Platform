import { Router } from 'express';
import { ToolController } from '../controllers/tool.controller';
import { authMiddleware } from '../middleware/auth.middleware';

const router = Router();

router.use(authMiddleware as any);

router.get('/', ToolController.getTools);
router.get('/:domain', ToolController.getToolByDomain);

export default router;
