import { Router } from 'express';
import { UserController } from '../controllers/user.controller';
import { authMiddleware } from '../middleware/auth.middleware';

const router = Router();

router.use(authMiddleware as any);

router.get('/me', UserController.getMe as any);
router.patch('/me', UserController.updateProfile as any);

export default router;
