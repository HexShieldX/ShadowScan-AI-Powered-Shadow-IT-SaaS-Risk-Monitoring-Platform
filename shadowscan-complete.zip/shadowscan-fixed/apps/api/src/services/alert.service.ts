import nodemailer from 'nodemailer';
import axios from 'axios';
import { PrismaClient, Severity } from '@prisma/client';
import { logger } from '../utils/logger';
import { emitToCompany } from '../utils/socket';

const prisma = new PrismaClient();

export class AlertService {
  private static transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT),
    secure: false,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  });

  public static async createAlert(data: {
    message: string;
    severity: Severity;
    userId: string;
    companyId: string;
    scanId: string;
  }) {
    const alert = await prisma.alert.create({
      data,
      include: { user: true }
    });

    // Real-time notification
    emitToCompany(data.companyId, 'new-alert', alert);

    // External notifications for high severity
    if (data.severity === Severity.HIGH || data.severity === Severity.CRITICAL) {
      this.sendEmail(alert);
      this.sendSlack(alert);
    }

    return alert;
  }

  private static async sendEmail(alert: any) {
    if (!process.env.SMTP_USER) return;
    try {
      await this.transporter.sendMail({
        from: process.env.SMTP_FROM,
        to: alert.user.email,
        subject: `[ShadowScan] ${alert.severity} Alert: ${alert.message}`,
        text: `A new security alert has been triggered: ${alert.message}\nSeverity: ${alert.severity}`,
      });
    } catch (error) {
      logger.error(`Failed to send alert email: ${error}`);
    }
  }

  private static async sendSlack(alert: any) {
    if (!process.env.SLACK_WEBHOOK_URL) return;
    try {
      await axios.post(process.env.SLACK_WEBHOOK_URL, {
        text: `🚨 *ShadowScan Alert*\n*Severity:* ${alert.severity}\n*Message:* ${alert.message}\n*User:* ${alert.user.name}`,
      });
    } catch (error) {
      logger.error(`Failed to send slack alert: ${error}`);
    }
  }
}
