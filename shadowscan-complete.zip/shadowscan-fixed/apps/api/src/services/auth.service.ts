import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { PrismaClient, User, Role } from '@prisma/client';
import { UnauthorizedError, BadRequestError } from '../utils/errors';

const prisma = new PrismaClient();

export class AuthService {
  private static ACCESS_TOKEN_EXPIRES = '15m';
  private static REFRESH_TOKEN_EXPIRES = '7d';

  public static generateTokens(user: Partial<User>) {
    const secret = process.env.JWT_SECRET || 'fallback_secret';
    const refreshSecret = process.env.JWT_REFRESH_SECRET || 'fallback_refresh_secret';

    const accessToken = jwt.sign(
      { id: user.id, email: user.email, role: user.role, companyId: user.companyId },
      secret,
      { expiresIn: this.ACCESS_TOKEN_EXPIRES as any }
    );

    const refreshToken = jwt.sign(
      { id: user.id },
      refreshSecret,
      { expiresIn: this.REFRESH_TOKEN_EXPIRES as any }
    );

    return { accessToken, refreshToken };
  }

  public static async register(data: any) {
    if (!data.companyName && !data.companyId) {
      throw new BadRequestError('Company name or company ID is required');
    }

    const existingUser = await prisma.user.findUnique({ where: { email: data.email } });
    if (existingUser) throw new BadRequestError('Email already registered');

    let companyId = data.companyId;
    if (data.companyName) {
      const company = await prisma.company.create({ data: { name: data.companyName } });
      companyId = company.id;
    }

    const hashedPassword = await bcrypt.hash(data.password, 10);
    const user = await prisma.user.create({
      data: {
        email: data.email,
        password: hashedPassword,
        name: data.name,
        role: data.role || Role.EMPLOYEE,
        companyId,
      },
    });

    const tokens = this.generateTokens(user);
    await prisma.user.update({
      where: { id: user.id },
      data: { refreshToken: tokens.refreshToken },
    });

    return { ...tokens, user: { id: user.id, email: user.email, name: user.name, role: user.role, companyId: user.companyId } };
  }

  public static async login(data: any) {
    const user = await prisma.user.findUnique({ where: { email: data.email } });
    if (!user || !(await bcrypt.compare(data.password, user.password))) {
      throw new UnauthorizedError('Invalid credentials');
    }

    const tokens = this.generateTokens(user);
    await prisma.user.update({
      where: { id: user.id },
      data: { refreshToken: tokens.refreshToken },
    });

    return { ...tokens, user: { id: user.id, email: user.email, name: user.name, role: user.role, companyId: user.companyId } };
  }

  public static async refresh(token: string) {
    if (!token) throw new UnauthorizedError('No refresh token provided');
    try {
      const secret = process.env.JWT_REFRESH_SECRET || 'fallback_refresh_secret';
      const decoded = jwt.verify(token, secret) as any;
      const user = await prisma.user.findUnique({ where: { id: decoded.id } });

      if (!user || user.refreshToken !== token) {
        throw new UnauthorizedError('Invalid refresh token');
      }

      // Rotate refresh token
      const tokens = this.generateTokens(user);
      await prisma.user.update({
        where: { id: user.id },
        data: { refreshToken: tokens.refreshToken },
      });

      return tokens;
    } catch (error) {
      throw new UnauthorizedError('Invalid refresh token');
    }
  }

  public static async logout(userId: string) {
    await prisma.user.update({
      where: { id: userId },
      data: { refreshToken: null },
    });
  }
}
