import { PrismaClient } from '@prisma/client';
import { ForbiddenError, NotFoundError } from '../utils/errors';

const prisma = new PrismaClient();

export class PolicyService {
  public static async getCompanyPolicies(companyId: string) {
    return prisma.policy.findMany({
      where: { companyId },
      orderBy: { createdAt: 'desc' },
    });
  }

  public static async createPolicy(companyId: string, data: any) {
    return prisma.policy.create({
      data: { ...data, companyId },
    });
  }

  public static async updatePolicy(id: string, companyId: string, data: any) {
    const policy = await prisma.policy.findUnique({ where: { id } });
    if (!policy) throw new NotFoundError('Policy not found');
    if (policy.companyId !== companyId) throw new ForbiddenError('Access denied');

    return prisma.policy.update({ where: { id }, data });
  }

  public static async deletePolicy(id: string, companyId: string) {
    const policy = await prisma.policy.findUnique({ where: { id } });
    if (!policy) throw new NotFoundError('Policy not found');
    if (policy.companyId !== companyId) throw new ForbiddenError('Access denied');

    return prisma.policy.delete({ where: { id } });
  }
}

