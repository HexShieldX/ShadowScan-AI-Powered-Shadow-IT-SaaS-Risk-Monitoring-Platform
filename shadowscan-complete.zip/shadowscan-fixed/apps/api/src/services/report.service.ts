import PDFDocument from 'pdfkit';
import { PrismaClient } from '@prisma/client';
import { Response } from 'express';

const prisma = new PrismaClient();

export class ReportService {
  public static async generateCompanyReport(companyId: string, res: Response) {
    const company = await prisma.company.findUnique({
      where: { id: companyId },
      include: {
        scans: {
          orderBy: { createdAt: 'desc' },
          take: 50,
        },
      },
    });

    if (!company) throw new Error('Company not found');

    const doc = new PDFDocument();
    
    // Set headers
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename=ShadowScan_Report_${Date.now()}.pdf`);
    
    doc.pipe(res);

    // Title
    doc.fontSize(25).text('ShadowScan Security Report', { align: 'center' });
    doc.moveDown();
    doc.fontSize(16).text(`Company: ${company.name}`);
    doc.text(`Date: ${new Date().toLocaleDateString()}`);
    doc.moveDown();

    // Stats
    const totalScans = company.scans.length;
    const highRiskCount = company.scans.filter(s => s.verdict === 'HIGH_RISK' || s.verdict === 'BLOCKED').length;
    
    doc.fontSize(18).text('Executive Summary');
    doc.fontSize(12).text(`Total Scans Analyzed: ${totalScans}`);
    doc.text(`High Risk/Blocked Tools Detected: ${highRiskCount}`);
    doc.moveDown();

    // Scan Table
    doc.fontSize(18).text('Recent Scans');
    doc.moveDown();
    
    company.scans.forEach((scan: any, index: number) => {
      doc.fontSize(10).fillColor('#000000').text(`${index + 1}. ${scan.domain} - Score: ${scan.riskScore} - Verdict: ${scan.verdict}`);
      const reasons = scan.riskBreakdown?.reasons || [];
      if (reasons.length > 0) {
        doc.fontSize(8).fillColor('#666666').text(`   Risk Factors: ${reasons.join(', ')}`);
        doc.moveDown(0.5);
      }
    });

    doc.end();
  }
}
