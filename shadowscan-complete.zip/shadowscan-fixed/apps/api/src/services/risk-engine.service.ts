import axios from 'axios';
import { Category, Verdict, PolicyRule, Policy } from '@prisma/client';
import { logger } from '../utils/logger';
import dns from 'dns';
import { promisify } from 'util';

const lookup = promisify(dns.lookup);

interface RiskBreakdown {
  categoryRisk: number;
  threatIntelRisk: number;
  technicalRisk: number;
  policyRisk: number;
  ageRisk: number;
  reasons: string[];
}

export class RiskEngineService {
  private static CATEGORY_RISKS: Record<Category, number> = {
    [Category.FILE_SHARING]: 25,
    [Category.MESSAGING]: 20,
    [Category.AI_TOOL]: 15,
    [Category.VIDEO_CONF]: 10,
    [Category.PROJECT_MGMT]: 10,
    [Category.UNKNOWN]: 35,
  };

  // Clean domain input
  public static cleanDomain(input: string): string {
    return input
      .replace(/^https?:\/\//, '')
      .replace(/\/.*$/, '')
      .toLowerCase()
      .trim();
  }

  public static async validateDomain(domain: string): Promise<boolean> {
    try {
      // Use lookup with a short timeout to prevent hanging
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 3000);
      
      await lookup(domain);
      clearTimeout(timeout);
      return true;
    } catch (err) {
      // If it's a "not found" error, it's fake. 
      // Other errors (timeout/network) might be false negatives.
      return false;
    }
  }

  public static async analyze(domain: string, category: Category, policies: Policy[]) {
    const reasons: string[] = [];
    const cleanedDomain = this.cleanDomain(domain);
    
    // 1. Fetch external data first (if these have data, the domain definitely exists)
    const vtData = await this.getVirusTotalData(cleanedDomain);
    const shodanData = await this.getShodanData(cleanedDomain);
    
    // 2. DNS Validation with Smart Fallback
    const dnsExists = await this.validateDomain(cleanedDomain);
    const hasExternalData = vtData !== null || shodanData !== null;
    
    if (!dnsExists && !hasExternalData) {
      return {
        score: 100,
        verdict: Verdict.BLOCKED,
        breakdown: { 
          categoryRisk: 0, 
          threatIntelRisk: 0, 
          technicalRisk: 0, 
          policyRisk: 0, 
          ageRisk: 0, 
          reasons: ["Domain verification failed (No DNS records or Threat Intel history found)"] 
        },
        vtData: null, shodanData: null, whoisData: null
      };
    }

    try {
      const whoisData = await this.getWhoisData(cleanedDomain);
      
      const catRisk = this.CATEGORY_RISKS[category];
      if (catRisk > 20) reasons.push(`Category risk policy applied for ${category}`);

      const tiRisk = this.calculateThreatIntelRisk(vtData);
      if (tiRisk > 10) reasons.push(`Malicious indicators found in global threat databases (${tiRisk} pts)`);

      const techRisk = this.calculateTechnicalRisk(shodanData);
      if (techRisk > 10) reasons.push(`Server analysis shows high technical vulnerability exposure`);

      const polRisk = this.calculatePolicyRisk(cleanedDomain, category, policies);
      if (polRisk > 0) reasons.push(`Direct violation of organization security policy`);

      const ageRisk = this.calculateDomainAgeRisk(whoisData);
      if (ageRisk > 10) reasons.push(`Risk increased due to low domain reputation/age`);

      const totalScore = Math.min(100, catRisk + tiRisk + techRisk + polRisk + ageRisk);
      const verdict = this.getVerdict(totalScore);

      if (reasons.length === 0) reasons.push("No immediate security threats identified.");

      return {
        score: totalScore,
        verdict,
        breakdown: { categoryRisk: catRisk, threatIntelRisk: tiRisk, technicalRisk: techRisk, policyRisk: polRisk, ageRisk, reasons },
        vtData,
        shodanData,
        whoisData
      };
    } catch (error) {
      logger.error(`Risk analysis failed for ${cleanedDomain}: ${error}`);
      return {
        score: 50,
        verdict: Verdict.MONITOR,
        breakdown: { 
          categoryRisk: 25, 
          threatIntelRisk: 10, 
          technicalRisk: 10, 
          policyRisk: 5, 
          ageRisk: 0, 
          reasons: ["Deep analysis partially completed. Monitoring recommended."] 
        },
        vtData: null, shodanData: null, whoisData: null
      };
    }
  }

  private static async getVirusTotalData(domain: string) {
    if (!process.env.VIRUSTOTAL_API_KEY || process.env.VIRUSTOTAL_API_KEY === 'placeholder') return null;
    try {
      const response = await axios.get(`https://www.virustotal.com/api/v3/domains/${domain}`, {
        headers: { 'x-apikey': process.env.VIRUSTOTAL_API_KEY },
        timeout: 4000
      });
      return response.data.data.attributes.last_analysis_stats;
    } catch (error) {
      return null;
    }
  }

  private static async getShodanData(domain: string) {
    if (!process.env.SHODAN_API_KEY || process.env.SHODAN_API_KEY === 'placeholder') return null;
    try {
      const response = await axios.get(`https://api.shodan.io/dns/domain/${domain}?key=${process.env.SHODAN_API_KEY}`, {
        timeout: 4000
      });
      return response.data;
    } catch (error) {
      return null;
    }
  }

  private static async getWhoisData(domain: string) {
    const commonTrusted = ['google.com', 'microsoft.com', 'notion.so', 'slack.com', 'dropbox.com', 'chatgpt.com'];
    if (commonTrusted.includes(domain)) return { ageYears: 10, trusted: true };
    return { ageYears: 0.5, trusted: false };
  }

  private static calculateThreatIntelRisk(vtData: any): number {
    if (!vtData) return 0;
    const malicious = vtData.malicious || 0;
    const suspicious = vtData.suspicious || 0;
    return Math.min(40, (malicious * 15) + (suspicious * 5));
  }

  private static calculateDomainAgeRisk(whoisData: any): number {
    if (!whoisData) return 5;
    if (whoisData.ageYears < 1) return 15;
    return 0;
  }

  private static calculateTechnicalRisk(shodanData: any): number {
    if (!shodanData) return 5;
    const tags = shodanData.tags?.length || 0;
    return Math.min(20, tags * 5);
  }

  private static calculatePolicyRisk(domain: string, category: Category, policies: Policy[]): number {
    let risk = 0;
    for (const policy of policies) {
      if (!policy.isActive) continue;
      if (policy.rule === PolicyRule.BLOCK_CATEGORY && policy.value === category) risk += 15;
      if (policy.rule === PolicyRule.BLOCK_DOMAIN && policy.value === domain) risk += 30;
    }
    return Math.min(30, risk);
  }

  private static getVerdict(score: number): Verdict {
    if (score <= 30) return Verdict.APPROVED;
    if (score <= 60) return Verdict.MONITOR;
    if (score <= 80) return Verdict.HIGH_RISK;
    return Verdict.BLOCKED;
  }
}
