import { Server } from 'socket.io';
import { logger } from './logger';

let io: Server;

export const initSocket = (socketIo: Server) => {
  io = socketIo;

  io.on('connection', (socket) => {
    logger.info(`Socket connected: ${socket.id}`);

    socket.on('join-company', (companyId: string) => {
      socket.join(companyId);
      logger.info(`Socket ${socket.id} joined company: ${companyId}`);
    });

    socket.on('disconnect', () => {
      logger.info(`Socket disconnected: ${socket.id}`);
    });
  });
};

export const getIO = () => {
  if (!io) {
    throw new Error('Socket.io not initialized!');
  }
  return io;
};

export const emitToCompany = (companyId: string, event: string, data: any) => {
  if (io) {
    io.to(companyId).emit(event, data);
  }
};
