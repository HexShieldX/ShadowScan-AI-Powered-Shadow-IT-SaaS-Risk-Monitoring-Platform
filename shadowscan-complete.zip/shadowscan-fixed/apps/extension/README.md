# ShadowScan Chrome Extension v3.0

Industry-level Shadow IT detection extension for Chrome/Edge. Detects unauthorized SaaS usage in real-time, integrated with your ShadowScan API.

---

## 🚀 Features

| Feature | Description |
|---|---|
| **Real-time scanning** | Detects every domain visited and sends to your ShadowScan API |
| **Smart deduplication** | Configurable cooldown (default 1h) prevents redundant scans |
| **In-page risk banner** | Red/orange overlay on BLOCKED or HIGH RISK domains |
| **Badge indicator** | Extension icon shows ✓ / ⚠ / ! / ✕ per tab |
| **Desktop notifications** | OS-level alerts on critical detections |
| **Right-click scan** | Context menu to force-scan any page or link |
| **Session stats** | Popup shows detected / high-risk / blocked counts |
| **Options page** | Configure API URL, cooldown, toggles |
| **Token expiry handling** | Auto-prompts re-login on 401 |
| **Cache pruning** | Alarm-based cleanup every 30 minutes |

---

## 📦 Installation (Developer Mode)

1. Open `chrome://extensions`
2. Enable **Developer mode** (top right)
3. Click **Load unpacked**
4. Select the `shadowscan-extension/` folder

---

## ⚙️ First-Time Setup

After installing, the **Options page** opens automatically.

1. Set your **API Base URL** (default: `http://localhost:5000/api/v1`)
2. Click **Save Settings**
3. Click the extension icon → **Sign In** with your ShadowScan credentials

---

## 🏗 Architecture

```
manifest.json                  # MV3 manifest
├── src/background/index.js    # Service worker (core logic)
│   ├── webNavigation listener # Fires on every page load
│   ├── Queue processor        # Batched, rate-limited API calls
│   ├── Badge management       # Per-tab verdict badges
│   ├── Notifications          # OS alerts for BLOCKED/HIGH_RISK
│   └── Alarm handler          # Periodic cache pruning
├── src/content/index.js       # In-page risk banner overlay
├── src/popup/index.js         # Popup UI logic
├── popup.html                 # SOC-style popup (360px)
└── options.html               # Full settings page
```

---

## 🔌 API Contract

The extension calls your existing API:

```
POST /api/v1/scans
Authorization: Bearer <token>
{ "domain": "dropbox.com" }

→ { id, riskScore, verdict, riskBreakdown, ... }
```

Verdicts: `APPROVED` | `MONITOR` | `HIGH_RISK` | `BLOCKED`

---

## 🔒 Security Notes

- Tokens stored in `chrome.storage.local` (sandboxed per extension)
- No data leaves your network except to your own API
- CSP set to `script-src 'self'` — no inline scripts
- All API calls have 10s timeout + AbortSignal

---

## 🛠 Updating the API URL

Options page → change **API Base URL** → Save.  
Or programmatically: `chrome.storage.local.set({ config: { apiUrl: 'https://your-server/api/v1' } })`
