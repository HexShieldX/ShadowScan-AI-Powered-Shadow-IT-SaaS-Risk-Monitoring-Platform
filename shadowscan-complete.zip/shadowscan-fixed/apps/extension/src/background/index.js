/**
 * ShadowScan Background Service Worker
 * Handles: domain detection, deduplication, API communication,
 *          badge updates, notifications, alarm-based refresh
 */

// ─── Config ──────────────────────────────────────────────────────────────────
const DEFAULTS = {
  apiUrl: 'http://localhost:5000/api/v1',
  scanCooldown: 60 * 60 * 1000,      // 1 hour per domain
  alertCooldown: 4 * 60 * 60 * 1000, // 4 hours per domain alert
  batchSize: 5,                        // concurrent scan limit
  refreshInterval: 30,                 // minutes for alarm
};

const SKIP_DOMAINS = new Set([
  'localhost', '127.0.0.1', '0.0.0.0', '::1',
  'newtab', 'extensions', 'settings',
]);

const SKIP_PREFIXES = ['chrome', 'chrome-extension', 'about', 'data', 'javascript', 'file', 'blob'];

// ─── State (in-memory cache) ──────────────────────────────────────────────────
// Persisted to chrome.storage.local for cross-session continuity
let scanQueue = [];
let isProcessingQueue = false;
let sessionStats = { detected: 0, blocked: 0, highRisk: 0 };

// ─── Helpers ──────────────────────────────────────────────────────────────────
function extractDomain(url) {
  try {
    const parsed = new URL(url);
    if (SKIP_PREFIXES.includes(parsed.protocol.replace(':', ''))) return null;
    const host = parsed.hostname.toLowerCase();
    if (SKIP_DOMAINS.has(host)) return null;
    // Strip www. for canonical form
    return host.startsWith('www.') ? host.slice(4) : host;
  } catch {
    return null;
  }
}

async function getConfig() {
  const stored = await chrome.storage.local.get('config');
  return { ...DEFAULTS, ...(stored.config || {}) };
}

async function getToken() {
  const { auth } = await chrome.storage.local.get('auth');
  return auth?.accessToken || null;
}

async function getScanCache() {
  const { scanCache } = await chrome.storage.local.get('scanCache');
  return scanCache || {};
}

async function getAlertCache() {
  const { alertCache } = await chrome.storage.local.get('alertCache');
  return alertCache || {};
}

// ─── Badge management ─────────────────────────────────────────────────────────
async function updateBadgeForTab(tabId, domain) {
  if (!tabId || !domain) return;

  const { domainResults } = await chrome.storage.local.get('domainResults');
  const result = domainResults?.[domain];

  if (!result) {
    chrome.action.setBadgeText({ text: '', tabId }).catch(() => {});
    return;
  }

  const { verdict, riskScore } = result;
  const MAP = {
    BLOCKED:   { text: '✕',   color: '#ef4444' },
    HIGH_RISK: { text: '!',   color: '#f97316' },
    MONITOR:   { text: '⚠',   color: '#eab308' },
    APPROVED:  { text: '✓',   color: '#22c55e' },
  };

  const badge = MAP[verdict] || { text: '', color: '#6b7280' };
  chrome.action.setBadgeText({ text: badge.text, tabId }).catch(() => {});
  chrome.action.setBadgeBackgroundColor({ color: badge.color, tabId }).catch(() => {});
}

// ─── Notifications ────────────────────────────────────────────────────────────
async function sendNotification(domain, verdict, riskScore) {
  const config = await getConfig();
  const alertCache = await getAlertCache();
  const now = Date.now();

  // Rate-limit alerts per domain
  if (alertCache[domain] && (now - alertCache[domain]) < config.alertCooldown) return;

  if (verdict !== 'BLOCKED' && verdict !== 'HIGH_RISK') return;

  const messages = {
    BLOCKED:   `🚨 BLOCKED: ${domain} is flagged by threat intelligence. Score: ${riskScore}/100`,
    HIGH_RISK: `⚠️ HIGH RISK: ${domain} detected. Risk Score: ${riskScore}/100`,
  };

  chrome.notifications.create(`shadowscan-${domain}-${now}`, {
    type: 'basic',
    iconUrl: 'icons/icon48.png',
    title: 'ShadowScan Alert',
    message: messages[verdict],
    priority: verdict === 'BLOCKED' ? 2 : 1,
    buttons: [{ title: 'View Details' }],
  });

  alertCache[domain] = now;
  await chrome.storage.local.set({ alertCache });
}

// ─── Content script messaging ─────────────────────────────────────────────────
async function notifyContentScript(tabId, domain, result) {
  try {
    await chrome.tabs.sendMessage(tabId, {
      type: 'SCAN_RESULT',
      domain,
      verdict: result.verdict,
      riskScore: result.riskScore,
    });
  } catch {
    // Tab may have navigated away, ignore
  }
}

// ─── Core scan logic ──────────────────────────────────────────────────────────
async function scanDomain(domain, tabId) {
  const config = await getConfig();
  const token = await getToken();

  if (!token) return null; // Not authenticated

  const scanCache = await getScanCache();
  const now = Date.now();

  // Check cooldown
  if (scanCache[domain] && (now - scanCache[domain].timestamp) < config.scanCooldown) {
    return scanCache[domain].result;
  }

  try {
    const response = await fetch(`${config.apiUrl}/scans`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
      body: JSON.stringify({ domain }),
      signal: AbortSignal.timeout(10000),
    });

    if (response.status === 401) {
      // Token expired — clear auth and prompt re-login
      await chrome.storage.local.remove(['auth']);
      chrome.action.setBadgeText({ text: '!' }).catch(() => {});
      chrome.action.setBadgeBackgroundColor({ color: '#6b7280' }).catch(() => {});
      return null;
    }

    if (!response.ok) {
      console.warn(`[ShadowScan] API error ${response.status} for ${domain}`);
      return null;
    }

    const scan = await response.json();
    const result = {
      riskScore: scan.riskScore,
      verdict: scan.verdict,
      breakdown: scan.riskBreakdown,
      scanId: scan.id,
      scannedAt: now,
    };

    // Persist result
    const { domainResults = {} } = await chrome.storage.local.get('domainResults');
    domainResults[domain] = result;
    scanCache[domain] = { timestamp: now, result };
    await chrome.storage.local.set({ domainResults, scanCache });

    // Update session stats
    sessionStats.detected++;
    if (result.verdict === 'BLOCKED') sessionStats.blocked++;
    if (result.verdict === 'HIGH_RISK') sessionStats.highRisk++;
    await chrome.storage.local.set({ sessionStats });

    return result;
  } catch (err) {
    console.error(`[ShadowScan] Scan failed for ${domain}:`, err.message);
    return null;
  }
}

// ─── Queue processor (rate-limited) ──────────────────────────────────────────
async function processQueue() {
  if (isProcessingQueue || scanQueue.length === 0) return;
  isProcessingQueue = true;

  const config = await getConfig();

  while (scanQueue.length > 0) {
    const batch = scanQueue.splice(0, config.batchSize);

    await Promise.all(batch.map(async ({ domain, tabId }) => {
      const result = await scanDomain(domain, tabId);
      if (result && tabId) {
        await updateBadgeForTab(tabId, domain);
        await notifyContentScript(tabId, domain, result);
        await sendNotification(domain, result.verdict, result.riskScore);
      }
    }));

    // Brief pause between batches to be kind to the API
    if (scanQueue.length > 0) {
      await new Promise(r => setTimeout(r, 500));
    }
  }

  isProcessingQueue = false;
}

function enqueueDomain(domain, tabId) {
  // Prevent duplicates in queue
  const exists = scanQueue.some(item => item.domain === domain);
  if (!exists) {
    scanQueue.push({ domain, tabId });
  }
  processQueue();
}

// ─── Navigation listener ──────────────────────────────────────────────────────
chrome.webNavigation.onCompleted.addListener(async (details) => {
  if (details.frameId !== 0) return; // Main frame only

  const domain = extractDomain(details.url);
  if (!domain) return;

  enqueueDomain(domain, details.tabId);
});

// Also catch tab updates (e.g. SPA navigations)
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete' || !tab.url) return;

  const domain = extractDomain(tab.url);
  if (!domain) return;

  // Refresh badge from cache immediately
  await updateBadgeForTab(tabId, domain);
});

// ─── Message handler (from popup & content script) ───────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const handle = async () => {
    switch (message.type) {
      case 'GET_CURRENT_DOMAIN_RESULT': {
        const { domain } = message;
        const { domainResults = {} } = await chrome.storage.local.get('domainResults');
        return domainResults[domain] || null;
      }

      case 'FORCE_SCAN': {
        const { domain } = message;
        // Clear cache for fresh scan
        const scanCache = await getScanCache();
        delete scanCache[domain];
        await chrome.storage.local.set({ scanCache });
        const result = await scanDomain(domain, sender.tab?.id);
        if (result) {
          await sendNotification(domain, result.verdict, result.riskScore);
        }
        return result;
      }

      case 'GET_SESSION_STATS': {
        const { sessionStats: stored } = await chrome.storage.local.get('sessionStats');
        return stored || { detected: 0, blocked: 0, highRisk: 0 };
      }

      case 'GET_AUTH_STATUS': {
        const token = await getToken();
        if (!token) return { authenticated: false };
        const { auth } = await chrome.storage.local.get('auth');
        return { authenticated: true, user: auth?.user };
      }

      case 'LOGOUT': {
        await chrome.storage.local.remove(['auth']);
        chrome.action.setBadgeText({ text: '' }).catch(() => {});
        return { success: true };
      }

      default:
        return null;
    }
  };

  handle().then(sendResponse).catch(err => {
    console.error('[ShadowScan BG] Message error:', err);
    sendResponse({ error: err.message });
  });

  return true; // Keep channel open for async response
});

// ─── Context menu ─────────────────────────────────────────────────────────────
chrome.contextMenus.create({
  id: 'shadowscan-scan',
  title: 'Scan this domain with ShadowScan',
  contexts: ['page', 'link'],
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== 'shadowscan-scan') return;

  const url = info.linkUrl || tab?.url;
  const domain = extractDomain(url);
  if (!domain) return;

  const scanCache = await getScanCache();
  delete scanCache[domain];
  await chrome.storage.local.set({ scanCache });

  enqueueDomain(domain, tab?.id);
});

// ─── Notification click handler ───────────────────────────────────────────────
chrome.notifications.onButtonClicked.addListener((notifId) => {
  if (notifId.startsWith('shadowscan-')) {
    chrome.tabs.create({ url: 'popup.html' });
  }
});

// ─── Alarm: periodic cache cleanup & token refresh ───────────────────────────
chrome.alarms.create('shadowscan-refresh', { periodInMinutes: DEFAULTS.refreshInterval });

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== 'shadowscan-refresh') return;

  // Prune old scan cache entries (older than 24h)
  const cutoff = Date.now() - 24 * 60 * 60 * 1000;
  const scanCache = await getScanCache();
  let pruned = 0;
  for (const [domain, entry] of Object.entries(scanCache)) {
    if (entry.timestamp < cutoff) {
      delete scanCache[domain];
      pruned++;
    }
  }
  if (pruned > 0) {
    await chrome.storage.local.set({ scanCache });
    console.log(`[ShadowScan] Pruned ${pruned} stale cache entries`);
  }
});

// ─── Install / Update handler ─────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === 'install') {
    // Set defaults
    await chrome.storage.local.set({
      config: DEFAULTS,
      scanCache: {},
      domainResults: {},
      alertCache: {},
      sessionStats: { detected: 0, blocked: 0, highRisk: 0 },
    });
    // Open options page for initial setup
    chrome.tabs.create({ url: 'options.html' });
  }
});

console.log('[ShadowScan] Service worker initialized ✓');
