/**
 * ShadowScan Content Script
 * Shows a subtle risk overlay on blocked/high-risk domains
 * and listens for messages from the background service worker.
 */

(function () {
  'use strict';

  // Prevent double injection
  if (window.__shadowScanInjected) return;
  window.__shadowScanInjected = true;

  const VERDICT_CONFIG = {
    BLOCKED: {
      color: '#ef4444',
      bg: 'rgba(239, 68, 68, 0.08)',
      border: 'rgba(239, 68, 68, 0.3)',
      icon: '🚫',
      label: 'BLOCKED',
    },
    HIGH_RISK: {
      color: '#f97316',
      bg: 'rgba(249, 115, 22, 0.08)',
      border: 'rgba(249, 115, 22, 0.3)',
      icon: '⚠️',
      label: 'HIGH RISK',
    },
  };

  function showRiskBanner(domain, verdict, riskScore) {
    const cfg = VERDICT_CONFIG[verdict];
    if (!cfg) return;
    if (document.getElementById('shadowscan-banner')) return; // Already shown

    const banner = document.createElement('div');
    banner.id = 'shadowscan-banner';
    banner.setAttribute('role', 'alert');
    banner.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 2147483647;
      background: ${cfg.bg};
      border-bottom: 2px solid ${cfg.border};
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
      padding: 10px 20px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      font-size: 13px;
      color: ${cfg.color};
      box-shadow: 0 2px 12px rgba(0,0,0,0.15);
      animation: shadowscan-slidein 0.3s ease;
    `;

    banner.innerHTML = `
      <style>
        @keyframes shadowscan-slidein {
          from { transform: translateY(-100%); opacity: 0; }
          to   { transform: translateY(0);     opacity: 1; }
        }
        #shadowscan-banner * { box-sizing: border-box; }
        #shadowscan-banner a { color: ${cfg.color}; text-decoration: underline; cursor: pointer; }
        #shadowscan-dismiss {
          background: none; border: 1px solid ${cfg.border};
          color: ${cfg.color}; padding: 4px 10px; border-radius: 4px;
          cursor: pointer; font-size: 12px; white-space: nowrap;
        }
        #shadowscan-dismiss:hover { background: ${cfg.border}; }
      </style>
      <span style="display:flex;align-items:center;gap:8px;font-weight:600;letter-spacing:0.02em;">
        <span style="font-size:16px">${cfg.icon}</span>
        ShadowScan: ${cfg.label}
        <span style="font-weight:400;opacity:0.8;">— ${domain} · Risk Score: <strong>${riskScore}/100</strong></span>
      </span>
      <button id="shadowscan-dismiss" aria-label="Dismiss">Dismiss</button>
    `;

    document.documentElement.insertBefore(banner, document.documentElement.firstChild);

    document.getElementById('shadowscan-dismiss').addEventListener('click', () => {
      banner.style.animation = 'none';
      banner.style.transition = 'opacity 0.2s';
      banner.style.opacity = '0';
      setTimeout(() => banner.remove(), 200);
    });

    // Auto-dismiss after 8 seconds for MONITOR, never for BLOCKED
    if (verdict !== 'BLOCKED') {
      setTimeout(() => {
        if (document.getElementById('shadowscan-banner')) {
          document.getElementById('shadowscan-dismiss')?.click();
        }
      }, 8000);
    }
  }

  // Listen for results from the background service worker
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'SCAN_RESULT') {
      const { domain, verdict, riskScore } = message;
      showRiskBanner(domain, verdict, riskScore);
    }
  });

})();
