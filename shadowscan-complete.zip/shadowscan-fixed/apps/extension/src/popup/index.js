/**
 * ShadowScan Popup Script
 */

// ─── Helpers ──────────────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);

function showView(name) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  $(`view-${name}`).classList.add('active');
}

function msgBg(type, payload = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type, ...payload }, response => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(response);
      }
    });
  });
}

function scoreColor(score) {
  if (score <= 30) return '#3fb950';
  if (score <= 60) return '#d29922';
  if (score <= 80) return '#db6d28';
  return '#f85149';
}

function timeAgo(timestamp) {
  const seconds = Math.floor((Date.now() - timestamp) / 1000);
  if (seconds < 60)  return `${seconds}s ago`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  return `${Math.floor(seconds / 3600)}h ago`;
}

function extractDomain(url) {
  try {
    const h = new URL(url).hostname.toLowerCase();
    return h.startsWith('www.') ? h.slice(4) : h;
  } catch { return null; }
}

// ─── Render result ────────────────────────────────────────────────────────────
function renderResult(result) {
  $('dash-scanning').style.display = 'none';
  $('dash-no-result').style.display = 'none';

  if (!result) {
    $('dash-no-result').style.display = 'block';
    return;
  }

  $('dash-result').style.display = 'block';

  const { verdict, riskScore, breakdown, scannedAt } = result;

  // Verdict badge
  const badge = $('verdict-badge');
  badge.className = `verdict-badge verdict-${verdict}`;
  const LABELS = { APPROVED: '✓ Approved', MONITOR: '⚠ Monitor', HIGH_RISK: '! High Risk', BLOCKED: '✕ Blocked' };
  badge.textContent = LABELS[verdict] || verdict;

  // Scan time
  if (scannedAt) $('scan-time').textContent = `Scanned ${timeAgo(scannedAt)}`;

  // Score bar
  const color = scoreColor(riskScore);
  $('score-bar').style.width = `${riskScore}%`;
  $('score-bar').style.background = color;
  $('score-num').style.color = color;
  $('score-num').textContent = riskScore;

  // Breakdown
  const breakdownEl = $('breakdown-rows');
  breakdownEl.innerHTML = '';
  if (breakdown) {
    const fields = [
      ['Category', breakdown.categoryRisk],
      ['Threat Intel', breakdown.threatIntelRisk],
      ['Technical', breakdown.technicalRisk],
      ['Policy', breakdown.policyRisk],
      ['Domain Age', breakdown.ageRisk],
    ];
    fields.forEach(([label, val]) => {
      if (val === undefined || val === null) return;
      const row = document.createElement('div');
      row.className = 'breakdown-row';
      row.innerHTML = `<span>${label}</span><span>${val} pts</span>`;
      breakdownEl.appendChild(row);
    });
  }

  // Reasons
  const reasonEl = $('reason-list');
  if (breakdown?.reasons?.length) {
    reasonEl.innerHTML = breakdown.reasons
      .map(r => `<div class="reason-item">${r}</div>`)
      .join('');
    reasonEl.style.display = 'block';
  } else {
    reasonEl.style.display = 'none';
  }
}

// ─── Session stats ────────────────────────────────────────────────────────────
async function loadStats() {
  try {
    const stats = await msgBg('GET_SESSION_STATS');
    if (stats) {
      $('stat-detected').textContent = stats.detected;
      $('stat-highrisk').textContent = stats.highRisk;
      $('stat-blocked').textContent  = stats.blocked;
    }
  } catch { /* ignore */ }
}

// ─── Load current tab's domain ────────────────────────────────────────────────
async function loadCurrentDomain() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url) return null;
  return extractDomain(tab.url);
}

// ─── Main init ────────────────────────────────────────────────────────────────
async function init() {
  // Check auth
  let authStatus;
  try {
    authStatus = await msgBg('GET_AUTH_STATUS');
  } catch {
    authStatus = { authenticated: false };
  }

  if (!authStatus?.authenticated) {
    showView('login');
    return;
  }

  // Show dashboard
  showView('dash');

  // Show user
  if (authStatus.user?.email) {
    $('logged-in-user').textContent = authStatus.user.email;
  }

  // Load domain
  const domain = await loadCurrentDomain();
  $('current-domain').textContent = domain || 'N/A';

  if (domain) {
    $('dash-no-result').style.display = 'none';
    $('dash-scanning').style.display = 'flex';

    try {
      const result = await msgBg('GET_CURRENT_DOMAIN_RESULT', { domain });
      renderResult(result);
    } catch {
      $('dash-scanning').style.display = 'none';
      $('dash-no-result').style.display = 'block';
    }
  }

  await loadStats();
}

// ─── Event listeners ──────────────────────────────────────────────────────────

// Login
$('login-btn').addEventListener('click', async () => {
  const email    = $('email-input').value.trim();
  const password = $('password-input').value;
  const errorEl  = $('login-error');
  errorEl.classList.remove('visible');

  if (!email || !password) {
    errorEl.textContent = 'Please enter email and password.';
    errorEl.classList.add('visible');
    return;
  }

  $('login-btn').textContent = 'Signing in…';
  $('login-btn').disabled = true;

  try {
    const { config: stored } = await chrome.storage.local.get('config');
    const apiUrl = stored?.apiUrl || 'http://localhost:5000/api/v1';

    const res = await fetch(`${apiUrl}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
      signal: AbortSignal.timeout(8000),
    });

    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      throw new Error(body.message || `HTTP ${res.status}`);
    }

    const data = await res.json();
    await chrome.storage.local.set({
      auth: { accessToken: data.accessToken, user: data.user },
    });

    init();
  } catch (err) {
    errorEl.textContent = `Login failed: ${err.message}`;
    errorEl.classList.add('visible');
  } finally {
    $('login-btn').textContent = 'Sign In';
    $('login-btn').disabled = false;
  }
});

// Enter key on inputs
[$('email-input'), $('password-input')].forEach(el => {
  el.addEventListener('keydown', e => { if (e.key === 'Enter') $('login-btn').click(); });
});

// Go to settings from login
$('go-settings-btn').addEventListener('click', async () => {
  const { config: stored } = await chrome.storage.local.get('config');
  $('api-url-input').value = stored?.apiUrl || 'http://localhost:5000/api/v1';
  showView('settings');
});

// Logout
$('logout-btn').addEventListener('click', async () => {
  await msgBg('LOGOUT');
  showView('login');
});

// Rescan
$('rescan-btn').addEventListener('click', async () => {
  const domain = $('current-domain').textContent;
  if (!domain || domain === '—' || domain === 'N/A') return;

  $('dash-result').style.display = 'none';
  $('dash-scanning').style.display = 'flex';

  try {
    const result = await msgBg('FORCE_SCAN', { domain });
    renderResult(result);
  } catch {
    $('dash-scanning').style.display = 'none';
    $('dash-no-result').style.display = 'block';
  }

  await loadStats();
});

// Open dashboard
$('open-dash-btn').addEventListener('click', () => {
  chrome.tabs.create({ url: 'http://localhost:3000' });
});

// Settings shortcut from dashboard
$('go-options-btn').addEventListener('click', async () => {
  const { config: stored } = await chrome.storage.local.get('config');
  $('api-url-input').value = stored?.apiUrl || 'http://localhost:5000/api/v1';
  showView('settings');
});

// Save settings
$('save-settings-btn').addEventListener('click', async () => {
  const url = $('api-url-input').value.trim();
  if (!url) return;

  const { config: existing } = await chrome.storage.local.get('config');
  await chrome.storage.local.set({ config: { ...(existing || {}), apiUrl: url } });

  $('save-settings-btn').textContent = '✓ Saved';
  setTimeout(() => { $('save-settings-btn').textContent = 'Save Settings'; }, 1500);
});

// Back button
$('back-btn').addEventListener('click', async () => {
  const { auth } = await chrome.storage.local.get('auth');
  showView(auth?.accessToken ? 'dash' : 'login');
});

// ─── Boot ─────────────────────────────────────────────────────────────────────
init();
