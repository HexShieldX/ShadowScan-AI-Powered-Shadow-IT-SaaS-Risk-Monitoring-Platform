"use client";
import { useEffect, useState } from "react";
import { format } from "date-fns";
import { Bell, CheckCircle, AlertTriangle, ShieldX } from "lucide-react";
import api from "@/lib/api";

export default function AlertsPage() {
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchAlerts = async () => {
    try {
      const { data } = await api.get("/alerts");
      setAlerts(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAlerts();
  }, []);

  const markAsRead = async (id: string) => {
    try {
      await api.patch(`/alerts/${id}/read`);
      fetchAlerts();
    } catch (err) {
      console.error(err);
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "CRITICAL": return <ShieldX className="text-red-600" size={24} />;
      case "HIGH": return <AlertTriangle className="text-orange-600" size={24} />;
      default: return <Bell className="text-blue-600" size={24} />;
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Security Alerts</h1>
        <p className="text-gray-500">Respond to high-risk tool detections.</p>
      </div>

      <div className="space-y-4">
        {loading ? (
          <div className="text-center py-20">Loading alerts...</div>
        ) : alerts.length === 0 ? (
          <div className="card p-10 text-center text-gray-500">
            All clear! No pending security alerts.
          </div>
        ) : (
          alerts.map((alert: any) => (
            <div key={alert.id} className={`card p-6 flex items-start gap-4 transition-opacity ${alert.isRead ? 'opacity-60' : ''}`}>
              <div className="p-2 rounded-full bg-gray-50">
                {getSeverityIcon(alert.severity)}
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-start">
                  <h4 className="font-bold">{alert.message}</h4>
                  <span className="text-xs text-gray-400">
                    {format(new Date(alert.createdAt), "MMM d, HH:mm")}
                  </span>
                </div>
                <div className="flex gap-4 mt-2 items-center">
                  <span className={`badge ${alert.severity === 'CRITICAL' ? 'badge-blocked' : 'badge-high_risk'}`}>
                    {alert.severity}
                  </span>
                  {!alert.isRead && (
                    <button 
                      onClick={() => markAsRead(alert.id)}
                      className="text-sm text-primary font-semibold flex items-center gap-1 hover:underline"
                    >
                      <CheckCircle size={16} />
                      Mark as resolved
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
