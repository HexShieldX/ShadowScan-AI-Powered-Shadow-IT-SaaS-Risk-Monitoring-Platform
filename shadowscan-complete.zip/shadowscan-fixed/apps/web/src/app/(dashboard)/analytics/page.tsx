"use client";
import { useEffect, useState } from "react";
import RiskTrendChart from "@/components/charts/RiskTrendChart";
import CategoryDonutChart from "@/components/charts/CategoryDonutChart";
import api from "@/lib/api";

export default function AnalyticsPage() {
  const [trendData, setTrendData] = useState([]);
  const [categoryData, setCategoryData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        const [trend, categories] = await Promise.all([
          api.get("/analytics/risk-trend"),
          api.get("/analytics/categories")
        ]);
        setTrendData(trend.data);
        setCategoryData(categories.data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchAnalytics();
  }, []);

  if (loading) return <div className="p-10 text-center">Loading Analytics...</div>;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Risk Analytics</h1>
        <p className="text-gray-500">Deep dive into organization-wide SaaS trends.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <RiskTrendChart data={trendData} />
        <CategoryDonutChart data={categoryData} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card p-6 bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <h4 className="text-sm font-medium opacity-80">Security Posture</h4>
          <h2 className="text-3xl font-bold mt-2">Strong</h2>
          <p className="text-xs mt-4 opacity-70">Up 12% from last month</p>
        </div>
        <div className="card p-6 bg-gradient-to-br from-orange-500 to-orange-600 text-white">
          <h4 className="text-sm font-medium opacity-80">Active Risks</h4>
          <h2 className="text-3xl font-bold mt-2">14 Tools</h2>
          <p className="text-xs mt-4 opacity-70">Require immediate review</p>
        </div>
        <div className="card p-6 bg-gradient-to-br from-purple-500 to-purple-600 text-white">
          <h4 className="text-sm font-medium opacity-80">Compliance Rate</h4>
          <h2 className="text-3xl font-bold mt-2">94%</h2>
          <p className="text-xs mt-4 opacity-70">Based on active policies</p>
        </div>
      </div>
    </div>
  );
}
