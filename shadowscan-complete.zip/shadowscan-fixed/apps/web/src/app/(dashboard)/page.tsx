"use client";
import { useEffect, useState } from "react";
import { Activity, ShieldAlert, Ban, Gauge, Download } from "lucide-react";
import StatCard from "@/components/dashboard/StatCard";
import QuickScanForm from "@/components/dashboard/QuickScanForm";
import RecentScansTable from "@/components/tables/RecentScansTable";
import LiveAlertFeed from "@/components/dashboard/LiveAlertFeed";
import api from "@/lib/api";
import { useSocket } from "@/hooks/useSocket";

export default function Dashboard() {
  const [stats, setStats] = useState({ totalScans: 0, highRisk: 0, blocked: 0, avgRiskScore: 0 });
  const [scans, setScans] = useState([]);
  const socket = useSocket();

  const fetchDashboardData = async () => {
    const [statsRes, scansRes] = await Promise.all([
      api.get("/analytics/overview"),
      api.get("/scans")
    ]);
    setStats(statsRes.data);
    setScans(scansRes.data);
  };

  useEffect(() => {
    fetchDashboardData();
    
    if (socket) {
      socket.on("new-scan", (scan) => {
        setScans((prev): any => [scan, ...prev].slice(0, 10));
        fetchDashboardData();
      });
    }
    
    return () => { socket?.off("new-scan"); };
  }, [socket]);

  const handleDownloadReport = async () => {
    const response = await api.get('/reports/generate', { responseType: 'blob' });
    const url = window.URL.createObjectURL(new Blob([response.data]));
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `ShadowScan_Report_${Date.now()}.pdf`);
    document.body.appendChild(link);
    link.click();
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Security Dashboard</h1>
          <p className="text-gray-500">Real-time Shadow IT monitoring and risk analysis.</p>
        </div>
        <button 
          onClick={handleDownloadReport}
          className="flex items-center gap-2 bg-white border border-gray-200 px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-50 shadow-sm"
        >
          <Download size={18} />
          Export Report
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Total Scans" value={stats.totalScans} icon={Activity} color="blue" />
        <StatCard title="High Risk Tools" value={stats.highRisk} icon={ShieldAlert} color="orange" />
        <StatCard title="Blocked Domains" value={stats.blocked} icon={Ban} color="red" />
        <StatCard title="Avg Risk Score" value={`${stats.avgRiskScore}/100`} icon={Gauge} color="green" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <QuickScanForm onScanComplete={fetchDashboardData} />
          <div className="mt-8">
            <RecentScansTable scans={scans} />
          </div>
        </div>
        <div>
          <LiveAlertFeed />
        </div>
      </div>
    </div>
  );
}
