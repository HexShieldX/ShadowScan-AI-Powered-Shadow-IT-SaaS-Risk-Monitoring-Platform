"use client";
import { useEffect, useState } from "react";
import RecentScansTable from "@/components/tables/RecentScansTable";
import api from "@/lib/api";
import { Search, Filter } from "lucide-react";

export default function ScansPage() {
  const [scans, setScans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    const fetchScans = async () => {
      try {
        const { data } = await api.get("/scans");
        setScans(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchScans();
  }, []);

  const filteredScans = scans.filter((scan: any) => 
    scan.domain.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold">Tool Inventory</h1>
          <p className="text-gray-500">History of all detected SaaS tools and domains.</p>
        </div>
      </div>

      <div className="flex gap-4 items-center bg-white p-4 rounded-xl border shadow-sm">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input
            type="text"
            placeholder="Search by domain..."
            className="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <button className="flex items-center gap-2 px-4 py-2 border rounded-lg text-sm font-medium hover:bg-gray-50">
          <Filter size={18} />
          Filters
        </button>
      </div>

      {loading ? (
        <div className="text-center py-20">Loading scans...</div>
      ) : (
        <RecentScansTable scans={filteredScans} />
      )}
    </div>
  );
}
