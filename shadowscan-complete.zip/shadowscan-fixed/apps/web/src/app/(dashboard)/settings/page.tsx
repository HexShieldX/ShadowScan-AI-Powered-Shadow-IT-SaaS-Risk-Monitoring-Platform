"use client";
import { useEffect, useState } from "react";
import { User, Building, Mail, ShieldCheck } from "lucide-react";
import api from "@/lib/api";
import { useAuthStore } from "@/store/auth.store";

export default function SettingsPage() {
  const { user } = useAuthStore();
  const [profile, setProfile] = useState<any>(null);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const { data } = await api.get("/users/me");
        setProfile(data);
      } catch (err) {
        console.error(err);
      }
    };
    fetchProfile();
  }, []);

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Account Settings</h1>
        <p className="text-gray-500">Manage your profile and organization details.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-1 space-y-4">
            <div className="card p-6 text-center">
                <div className="w-24 h-24 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4 text-3xl font-bold">
                    {user?.name?.[0] || 'U'}
                </div>
                <h3 className="font-bold text-lg">{user?.name}</h3>
                <p className="text-sm text-gray-500">{user?.role}</p>
            </div>
        </div>

        <div className="md:col-span-2 space-y-6">
            <div className="card divide-y">
                <div className="p-6">
                    <h3 className="font-bold flex items-center gap-2 mb-4">
                        <User size={18} className="text-blue-500" />
                        Personal Information
                    </h3>
                    <div className="grid grid-cols-1 gap-4">
                        <div>
                            <label className="text-xs font-bold text-gray-400 uppercase">Full Name</label>
                            <p className="font-medium">{user?.name}</p>
                        </div>
                        <div>
                            <label className="text-xs font-bold text-gray-400 uppercase">Email Address</label>
                            <p className="font-medium">{user?.email}</p>
                        </div>
                    </div>
                </div>

                <div className="p-6">
                    <h3 className="font-bold flex items-center gap-2 mb-4">
                        <Building size={18} className="text-blue-500" />
                        Organization Details
                    </h3>
                    <div className="grid grid-cols-1 gap-4">
                        <div>
                            <label className="text-xs font-bold text-gray-400 uppercase">Company ID</label>
                            <p className="font-mono text-sm">{user?.companyId}</p>
                        </div>
                        <div>
                            <label className="text-xs font-bold text-gray-400 uppercase">Security Status</label>
                            <p className="flex items-center gap-2 text-green-600 font-bold text-sm">
                                <ShieldCheck size={16} />
                                Verified Enterprise
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div className="card p-6 bg-blue-600 text-white">
                <h4 className="font-bold mb-2">Need a higher limit?</h4>
                <p className="text-sm opacity-90 mb-4">You are currently on the Enterprise Demo plan with unlimited scans.</p>
                <button className="bg-white text-blue-600 px-4 py-2 rounded-lg text-sm font-bold">Contact Sales</button>
            </div>
        </div>
      </div>
    </div>
  );
}
