"use client";
import { useEffect, useState } from "react";
import { Shield, Trash2, Plus } from "lucide-react";
import api from "@/lib/api";
import CreatePolicyForm from "@/components/dashboard/CreatePolicyForm";

export default function PoliciesPage() {
  const [policies, setPolicies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);

  const fetchPolicies = async () => {
    try {
      const { data } = await api.get("/policies");
      setPolicies(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPolicies();
  }, []);

  const togglePolicy = async (id: string, current: boolean) => {
    try {
      await api.patch(`/policies/${id}`, { isActive: !current });
      fetchPolicies();
    } catch (err) {
      alert("Only admins can change policies.");
    }
  };

  const deletePolicy = async (id: string) => {
    if (!confirm("Are you sure?")) return;
    try {
      await api.delete(`/policies/${id}`);
      fetchPolicies();
    } catch (err) {
      alert("Failed to delete policy.");
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Security Policies</h1>
        <p className="text-gray-500">Automated rules that drive the Shadow IT Risk Engine.</p>
      </div>

      {showCreate && (
        <CreatePolicyForm 
          onCancel={() => setShowCreate(false)} 
          onComplete={() => {
            setShowCreate(false);
            fetchPolicies();
          }} 
        />
      )}

      <div className="card divide-y">
        <div className="p-6 flex justify-between items-center bg-gray-50/50">
          <div>
            <h3 className="text-lg font-bold">Active Rules</h3>
            <p className="text-sm text-gray-500">Domains and categories flagged for monitoring.</p>
          </div>
          <button 
            onClick={() => setShowCreate(true)}
            className="bg-primary text-white px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 hover:bg-blue-600 transition-colors shadow-sm"
          >
            <Plus size={18} />
            Add New Rule
          </button>
        </div>

        {loading ? (
          <div className="p-20 text-center text-gray-400">Loading your security policies...</div>
        ) : policies.length === 0 ? (
          <div className="p-20 text-center text-gray-500 italic">No policies defined. All tools are currently using default risk scores.</div>
        ) : (
          policies.map((policy: any) => (
            <div key={policy.id} className="p-6 flex items-center justify-between hover:bg-blue-50/30 transition-colors">
              <div className="flex items-center gap-4">
                <div className={`p-3 rounded-xl ${policy.isActive ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-400'}`}>
                  <Shield size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-gray-900">{policy.name}</h4>
                  <p className="text-sm text-gray-500">
                    Rule: <span className="font-mono bg-gray-100 px-1.5 py-0.5 rounded text-xs">{policy.rule}</span> 
                    &nbsp;Value: <span className="font-semibold text-gray-700">{policy.value}</span>
                  </p>
                </div>
              </div>
              
              <div className="flex items-center gap-6">
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    checked={policy.isActive} 
                    onChange={() => togglePolicy(policy.id, policy.isActive)}
                    className="sr-only peer" 
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                </label>
                <button onClick={() => deletePolicy(policy.id)} className="text-gray-300 hover:text-red-600 transition-colors">
                  <Trash2 size={20} />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
