"use client";
import { ReactNode } from "react";

import { useAuthStore } from "@/store/auth.store";
import { useEffect, useState } from "react";

export function Providers({ children }: { children: ReactNode }) {
  const setAuth = useAuthStore((state) => state.setAuth);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('accessToken');
    const userStr = localStorage.getItem('user');
    
    if (token && userStr) {
      try {
        const user = JSON.parse(userStr);
        setAuth(user, token);
      } catch (e) {
        localStorage.clear();
      }
    }
    setReady(true);
  }, [setAuth]);

  if (!ready) return null;

  return <>{children}</>;
}
