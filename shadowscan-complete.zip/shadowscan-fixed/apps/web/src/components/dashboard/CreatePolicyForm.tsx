"use client";
import { useState } from "react";
import { Save, X } from "lucide-react";
import api from "@/lib/api";

export default function CreatePolicyForm({ onComplete, onCancel }: { onComplete: () => void; onCancel: () => void }) {
  const [formData, setFormData] = useState({
    name: "",
    rule: "BLOCK_CATEGORY",
    value: "AI_TOOL",
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await api.post("/policies", formData);
      onComplete();
    } catch (err) {
      alert("Failed to create policy. Ensure you have admin rights.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-gray-50 p-6 rounded-xl border mb-6 animate-in slide-in-from-top-4">
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-bold">New Security Policy</h3>
        <button onClick={onCancel} className="text-gray-400 hover:text-gray-600">
          <X size={20} />
        </button>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Policy Name</label>
          <input
            type="text"
            required
            className="w-full px-4 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="e.g., Restrict Shadow AI"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          />
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Rule Type</label>
            <select
              className="w-full px-4 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.rule}
              onChange={(e) => setFormData({ ...formData, rule: e.target.value })}
            >
              <option value="BLOCK_CATEGORY">Block Category</option>
              <option value="BLOCK_DOMAIN">Block Domain</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Value</label>
            <input
              type="text"
              required
              className="w-full px-4 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
              placeholder={formData.rule === 'BLOCK_CATEGORY' ? 'AI_TOOL, FILE_SHARING...' : 'domain.com'}
              value={formData.value}
              onChange={(e) => setFormData({ ...formData, value: e.target.value })}
            />
          </div>
        </div>

        <div className="flex justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 rounded-lg"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={loading}
            className="bg-primary text-white px-6 py-2 rounded-lg text-sm font-bold flex items-center gap-2 hover:bg-blue-600 disabled:opacity-50"
          >
            <Save size={18} />
            {loading ? "Saving..." : "Save Policy"}
          </button>
        </div>
      </form>
    </div>
  );
}
