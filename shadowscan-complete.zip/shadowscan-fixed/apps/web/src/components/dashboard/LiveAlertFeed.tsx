"use client";
import { useEffect, useState } from "react";
import { format } from "date-fns";
import { Bell, AlertCircle } from "lucide-react";
import { useSocket } from "@/hooks/useSocket";
import api from "@/lib/api";

export default function LiveAlertFeed() {
  const [alerts, setAlerts] = useState([]);
  const socket = useSocket();

  useEffect(() => {
    const fetchInitialAlerts = async () => {
      const { data } = await api.get("/alerts");
      setAlerts(data.slice(0, 5));
    };
    fetchInitialAlerts();

    if (socket) {
      socket.on("new-alert", (alert) => {
        setAlerts((prev): any => [alert, ...prev].slice(0, 5));
      });
    }

    return () => { socket?.off("new-alert"); };
  }, [socket]);

  return (
    <div className="card p-6 h-full">
      <div className="flex items-center gap-2 mb-6">
        <Bell className="text-primary" size={20} />
        <h3 className="text-lg font-bold">Live Alert Feed</h3>
      </div>

      <div className="space-y-6">
        {alerts.length === 0 ? (
          <div className="text-center py-10 text-gray-400 text-sm">No recent alerts</div>
        ) : (
          alerts.map((alert: any) => (
            <div key={alert.id} className="flex gap-4 group cursor-default">
              <div className={`mt-1 p-1.5 rounded-full h-fit ${
                alert.severity === 'CRITICAL' ? 'bg-red-50 text-red-500' : 
                alert.severity === 'HIGH' ? 'bg-orange-50 text-orange-500' : 
                'bg-blue-50 text-blue-500'
              }`}>
                <AlertCircle size={16} />
              </div>
              <div className="flex-1 min-w-0 border-b border-gray-50 pb-4 last:border-0 group-last:pb-0">
                <p className="text-sm font-bold text-gray-900 truncate">{alert.message}</p>
                <div className="flex justify-between items-center mt-1">
                   <span className="text-[10px] font-bold text-gray-400 uppercase">{alert.severity}</span>
                   <span className="text-[10px] text-gray-400">{format(new Date(alert.createdAt), "HH:mm")}</span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
