"use client";
import { useState } from "react";
import { Search, Loader2 } from "lucide-react";
import api from "@/lib/api";

export default function QuickScanForm({ onScanComplete }: { onScanComplete: () => void }) {
  const [domain, setDomain] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!domain) return;
    setLoading(true);
    try {
      const { data } = await api.post("/scans", { domain });
      setResult(data);
      setDomain("");
      onScanComplete();
    } catch (err: any) {
      const msg = err.response?.data?.message || "Analysis failed. Please check the domain format.";
      alert(`Analysis Error: ${msg}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="card p-6">
      <h3 className="text-lg font-bold mb-4">Quick Analysis</h3>
      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          placeholder="Enter domain (e.g. dropbox.com)"
          className="flex-1 px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
          value={domain}
          onChange={(e) => setDomain(e.target.value)}
        />
        <button
          disabled={loading}
          className="bg-primary text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-600 transition-colors flex items-center gap-2"
        >
          {loading ? <Loader2 className="animate-spin" size={20} /> : <Search size={20} />}
          Analyze
        </button>
      </form>

      {result && (
        <div className="mt-6 p-4 rounded-lg bg-gray-50 border border-gray-100 animate-in fade-in slide-in-from-top-4">
          <div className="flex justify-between items-center mb-2">
            <span className="font-bold text-lg">{result.domain}</span>
            <span className={`badge badge-${result.verdict.toLowerCase()}`}>{result.verdict}</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div 
              className={`h-2.5 rounded-full ${result.riskScore > 70 ? 'bg-red-500' : result.riskScore > 30 ? 'bg-orange-500' : 'bg-green-500'}`}
              style={{ width: `${result.riskScore}%` }}
            ></div>
          </div>
          <div className="mt-4 space-y-2">
            <p className="text-sm font-bold text-gray-700">Analysis Reasoning:</p>
            <ul className="text-xs text-gray-600 list-disc pl-4 space-y-1">
              {(result.riskBreakdown?.reasons || []).map((reason: string, i: number) => (
                <li key={i}>{reason}</li>
              ))}
            </ul>
          </div>
          <p className="mt-3 text-sm text-gray-600">Total Risk: <span className="font-bold">{result.riskScore}/100</span></p>
        </div>
      )}
    </div>
  );
}
