import { format } from "date-fns";

export default function RecentScansTable({ scans }: { scans: any[] }) {
  return (
    <div className="card">
      <div className="px-6 py-4 border-b">
        <h3 className="text-lg font-bold">Recent Scans</h3>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead className="bg-gray-50 text-gray-500 text-xs uppercase font-medium">
            <tr>
              <th className="px-6 py-3">Domain</th>
              <th className="px-6 py-3">Risk Score</th>
              <th className="px-6 py-3">Verdict</th>
              <th className="px-6 py-3">User</th>
              <th className="px-6 py-3">Date</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {scans.length === 0 ? (
              <tr>
                <td colSpan={5} className="px-6 py-10 text-center text-gray-500">No scans found</td>
              </tr>
            ) : (
              scans.map((scan) => (
                <tr key={scan.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 font-medium">{scan.domain}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <div className="w-16 bg-gray-200 rounded-full h-1.5">
                        <div 
                          className={`h-1.5 rounded-full ${scan.riskScore > 70 ? 'bg-red-500' : scan.riskScore > 30 ? 'bg-orange-500' : 'bg-green-500'}`}
                          style={{ width: `${scan.riskScore}%` }}
                        ></div>
                      </div>
                      <span className="text-sm">{scan.riskScore}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`badge badge-${scan.verdict.toLowerCase()}`}>
                      {scan.verdict}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600">{scan.user.name}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">
                    {format(new Date(scan.createdAt), "MMM d, HH:mm")}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
