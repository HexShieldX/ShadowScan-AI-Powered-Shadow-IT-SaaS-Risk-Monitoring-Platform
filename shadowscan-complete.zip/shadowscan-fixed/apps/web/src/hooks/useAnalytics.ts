"use client";
import { useState, useEffect } from "react";
import api from "@/lib/api";

export const useAnalytics = () => {
  const [data, setData] = useState({
    overview: null,
    trend: [],
    categories: [],
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAll = async () => {
      try {
        const [overview, trend, categories] = await Promise.all([
          api.get("/analytics/overview"),
          api.get("/analytics/risk-trend"),
          api.get("/analytics/categories"),
        ]);
        setData({
          overview: overview.data,
          trend: trend.data,
          categories: categories.data,
        });
      } catch (err) {
        console.error("Analytics fetch failed", err);
      } finally {
        setLoading(false);
      }
    };
    fetchAll();
  }, []);

  return { ...data, loading };
};
