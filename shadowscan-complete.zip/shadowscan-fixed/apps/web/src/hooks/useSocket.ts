"use client";
import { useEffect, useState } from "react";
import { io, Socket } from "socket.io-client";
import { useAuthStore } from "@/store/auth.store";

export const useSocket = () => {
  const [socket, setSocket] = useState<Socket | null>(null);
  const { user } = useAuthStore();

  useEffect(() => {
    const socketInstance = io(process.env.NEXT_PUBLIC_WS_URL || "http://localhost:5000", {
      withCredentials: true,
    });

    socketInstance.on("connect", () => {
      console.log("Connected to WebSocket");
      if (user?.companyId) {
        socketInstance.emit("join-company", user.companyId);
      }
    });

    setSocket(socketInstance);

    return () => {
      socketInstance.disconnect();
    };
  }, [user?.companyId]);

  return socket;
};
