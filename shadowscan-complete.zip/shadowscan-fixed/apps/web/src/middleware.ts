import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function middleware(request: NextRequest) {
  const token = request.cookies.get('refreshToken')?.value;
  const { pathname } = request.nextUrl;

  // Protect dashboard routes
  if (pathname === '/' || pathname.startsWith('/scans') || pathname.startsWith('/analytics') || pathname.startsWith('/alerts') || pathname.startsWith('/settings')) {
    if (!token && !request.headers.get('Authorization')) {
      // In a real production app, we'd verify the JWT here or rely on the client-side check
      // For this implementation, we allow the request but the client-side store will handle the redirect if needed
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/((?!api|_next/static|_next/image|favicon.ico).*)'],
};
