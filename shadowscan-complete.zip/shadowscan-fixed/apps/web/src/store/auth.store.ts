import { create } from 'zustand';

interface User {
  id: string;
  email: string;
  name: string;
  role: string;
  companyId: string;
}

interface AuthState {
  user: User | null;
  accessToken: string | null;
  setAuth: (user: User, token: string) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  accessToken: null,
  setAuth: (user, token) => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('accessToken', token);
      window.localStorage.setItem('user', JSON.stringify(user));
    }
    set({ user, accessToken: token });
  },
  logout: () => {
    if (typeof window !== 'undefined') {
      window.localStorage.removeItem('accessToken');
      window.localStorage.removeItem('user');
    }
    set({ user: null, accessToken: null });
  },
}));
