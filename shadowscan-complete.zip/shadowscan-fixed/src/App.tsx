import React, { useState } from "react";
import { 
  LayoutDashboard, 
  Search, 
  BarChart2, 
  Bell, 
  Settings, 
  Shield, 
  Activity, 
  ShieldAlert, 
  Ban, 
  Gauge, 
  Download,
  AlertCircle,
  CheckCircle,
  Loader2
} from "lucide-react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend
} from 'recharts';

// --- MOCK DATA FOR PREVIEW ---
const MOCK_STATS = { totalScans: 1248, highRisk: 14, blocked: 5, avgRiskScore: 32 };
const MOCK_TREND = [
  { date: '2024-03-01', avgRisk: 25 }, { date: '2024-03-05', avgRisk: 28 },
  { date: '2024-03-10', avgRisk: 42 }, { date: '2024-03-15', avgRisk: 30 },
  { date: '2024-03-20', avgRisk: 35 }, { date: '2024-03-25', avgRisk: 32 },
];
const MOCK_CATEGORIES = [
  { name: 'AI Tools', value: 400 }, { name: 'File Sharing', value: 300 },
  { name: 'Messaging', value: 300 }, { name: 'Others', value: 200 },
];
const MOCK_SCANS = [
  { id: '1', domain: 'chatgpt.com', riskScore: 15, verdict: 'APPROVED', user: 'Admin', createdAt: '2024-03-26T10:00:00Z' },
  { id: '2', domain: 'dropbox.com', riskScore: 45, verdict: 'MONITOR', user: 'Employee A', createdAt: '2024-03-26T09:30:00Z' },
  { id: '3', domain: 'malicious-site.io', riskScore: 85, verdict: 'BLOCKED', user: 'Employee B', createdAt: '2024-03-26T08:15:00Z' },
];
const MOCK_ALERTS = [
  { id: '1', message: 'High risk tool detected: malicious-site.io', severity: 'CRITICAL', createdAt: '2024-03-26T08:15:00Z' },
  { id: '2', message: 'New AI tool usage: Jasper.ai', severity: 'LOW', createdAt: '2024-03-26T07:45:00Z' },
];

const COLORS = ['#3b82f6', '#ef4444', '#f59e0b', '#10b981', '#6366f1'];

export default function App() {
  const [activeTab, setActiveTab] = useState("Dashboard");
  const [loading, setLoading] = useState(false);
  const [scanDomain, setScanDomain] = useState("");
  const [scanResult, setScanResult] = useState<any>(null);

  const handleScan = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setScanResult({
        domain: scanDomain,
        riskScore: Math.floor(Math.random() * 100),
        verdict: scanDomain.includes('danger') ? 'BLOCKED' : 'APPROVED'
      });
      setLoading(false);
    }, 1500);
  };

  return (
    <div className="flex h-screen bg-slate-50 font-sans text-slate-900">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-slate-200 flex flex-col shadow-sm">
        <div className="p-6">
          <div className="flex items-center gap-3 text-blue-600 font-black text-2xl tracking-tighter">
            <div className="bg-blue-600 text-white p-1.5 rounded-lg">
              <Shield size={24} fill="white" />
            </div>
            <span>ShadowScan<span className="text-slate-400">v2</span></span>
          </div>
        </div>
        
        <nav className="flex-1 px-4 space-y-1">
          {[
            { label: "Dashboard", icon: LayoutDashboard },
            { label: "All Scans", icon: Search },
            { label: "Analytics", icon: BarChart2 },
            { label: "Alerts", icon: Bell },
            { label: "Policies", icon: Shield },
            { label: "Settings", icon: Settings },
          ].map((item) => (
            <button
              key={item.label}
              onClick={() => setActiveTab(item.label)}
              className={`flex items-center gap-3 px-4 py-3 w-full rounded-xl text-sm font-semibold transition-all ${
                activeTab === item.label 
                ? "bg-blue-600 text-white shadow-lg shadow-blue-200" 
                : "text-slate-500 hover:bg-slate-100"
              }`}
            >
              <item.icon size={20} />
              {item.label}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-slate-100">
          <div className="bg-slate-900 rounded-2xl p-4 text-white">
            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Status</p>
            <div className="flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
              <p className="text-sm font-bold">Engine: Healthy</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-10">
        <div className="max-w-7xl mx-auto space-y-8">
          
          {/* Header */}
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-4xl font-black tracking-tight">{activeTab}</h1>
              <p className="text-slate-500 font-medium mt-1">Real-time Shadow IT monitoring and risk analysis.</p>
            </div>
            <button className="flex items-center gap-2 bg-white border border-slate-200 px-5 py-2.5 rounded-xl text-sm font-bold hover:bg-slate-50 shadow-sm transition-all active:scale-95">
              <Download size={18} />
              Export Security Report
            </button>
          </div>

          {activeTab === "Dashboard" && (
            <>
              {/* Stats Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard title="Total Scans" value={MOCK_STATS.totalScans} icon={Activity} color="blue" trend="+12% from last week" />
                <StatCard title="High Risk Tools" value={MOCK_STATS.highRisk} icon={ShieldAlert} color="orange" trend="2 new today" />
                <StatCard title="Blocked Domains" value={MOCK_STATS.blocked} icon={Ban} color="red" trend="Locked for safety" />
                <StatCard title="Avg Risk Score" value={`${MOCK_STATS.avgRiskScore}/100`} icon={Gauge} color="green" trend="Stable" />
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-8">
                  {/* Quick Scan */}
                  <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm">
                    <h3 className="text-xl font-black mb-6 flex items-center gap-2">
                      <Search size={22} className="text-blue-600" />
                      Instant Domain Analysis
                    </h3>
                    <form onSubmit={handleScan} className="flex gap-3">
                      <input
                        type="text"
                        placeholder="Enter domain (e.g. wetransfer.com)"
                        className="flex-1 px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-100 focus:border-blue-500 outline-none transition-all font-medium"
                        value={scanDomain}
                        onChange={(e) => setScanDomain(e.target.value)}
                      />
                      <button
                        disabled={loading}
                        className="bg-blue-600 text-white px-8 py-3.5 rounded-2xl font-bold hover:bg-blue-700 transition-all flex items-center gap-2 shadow-lg shadow-blue-100 disabled:opacity-50"
                      >
                        {loading ? <Loader2 className="animate-spin" size={20} /> : <Activity size={20} />}
                        Analyze
                      </button>
                    </form>

                    {scanResult && (
                      <div className="mt-8 p-6 rounded-2xl bg-slate-50 border border-slate-100 animate-in fade-in slide-in-from-top-4">
                        <div className="flex justify-between items-center mb-4">
                          <div>
                            <span className="text-2xl font-black block">{scanResult.domain}</span>
                            <span className="text-slate-500 text-sm font-medium italic">Detected via AI Risk Engine</span>
                          </div>
                          <span className={`px-4 py-2 rounded-full text-xs font-black tracking-widest uppercase shadow-sm ${
                            scanResult.verdict === 'BLOCKED' ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'
                          }`}>
                            {scanResult.verdict}
                          </span>
                        </div>
                        <div className="w-full bg-slate-200 rounded-full h-3 mb-3">
                          <div 
                            className={`h-3 rounded-full transition-all duration-1000 ${
                              scanResult.riskScore > 70 ? 'bg-red-500' : scanResult.riskScore > 30 ? 'bg-orange-500' : 'bg-green-500'
                            }`}
                            style={{ width: `${scanResult.riskScore}%` }}
                          ></div>
                        </div>
                        <p className="text-sm font-bold text-slate-600 uppercase tracking-tight"> Risk Intelligence Score: {scanResult.riskScore}/100</p>
                      </div>
                    )}
                  </div>

                  {/* Recent Scans Table */}
                  <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
                    <div className="px-8 py-6 border-b border-slate-100 bg-slate-50/50">
                      <h3 className="text-xl font-black">Recent Scan Inventory</h3>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left">
                        <thead className="bg-slate-50 text-slate-400 text-[10px] uppercase font-black tracking-widest">
                          <tr>
                            <th className="px-8 py-4">SaaS Domain</th>
                            <th className="px-8 py-4">Risk Matrix</th>
                            <th className="px-8 py-4">Verdict</th>
                            <th className="px-8 py-4">User</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {MOCK_SCANS.map((scan) => (
                            <tr key={scan.id} className="hover:bg-slate-50/80 transition-colors">
                              <td className="px-8 py-5 font-bold text-slate-900">{scan.domain}</td>
                              <td className="px-8 py-5">
                                <div className="flex items-center gap-3">
                                  <div className="w-20 bg-slate-100 rounded-full h-1.5">
                                    <div 
                                      className={`h-1.5 rounded-full ${scan.riskScore > 70 ? 'bg-red-500' : scan.riskScore > 30 ? 'bg-orange-500' : 'bg-green-500'}`}
                                      style={{ width: `${scan.riskScore}%` }}
                                    ></div>
                                  </div>
                                  <span className="text-xs font-black">{scan.riskScore}</span>
                                </div>
                              </td>
                              <td className="px-8 py-5">
                                <span className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider ${
                                  scan.verdict === 'APPROVED' ? 'bg-green-100 text-green-700' : 
                                  scan.verdict === 'MONITOR' ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-700'
                                }`}>
                                  {scan.verdict}
                                </span>
                              </td>
                              <td className="px-8 py-5 text-sm text-slate-500 font-medium">{scan.user}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>

                {/* Sidebar Cards */}
                <div className="space-y-8">
                  <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm">
                    <h3 className="text-xl font-black mb-6 flex items-center gap-2">
                      <Bell size={22} className="text-blue-600" />
                      Live Threat Feed
                    </h3>
                    <div className="space-y-6">
                      {MOCK_ALERTS.map((alert) => (
                        <div key={alert.id} className="flex gap-4 group">
                          <div className={`mt-1 p-2 rounded-xl h-fit shadow-sm ${
                            alert.severity === 'CRITICAL' ? 'bg-red-50 text-red-500' : 'bg-blue-50 text-blue-500'
                          }`}>
                            <AlertCircle size={18} />
                          </div>
                          <div className="flex-1 pb-4 border-b border-slate-50 group-last:border-0 group-last:pb-0">
                            <p className="text-sm font-bold text-slate-900 leading-tight mb-1">{alert.message}</p>
                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Just now • {alert.severity}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm h-[320px]">
                    <h3 className="text-xl font-black mb-4">Risk Trends</h3>
                    <ResponsiveContainer width="100%" height="80%">
                      <LineChart data={MOCK_TREND}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis dataKey="date" hide />
                        <YAxis hide domain={[0, 100]} />
                        <Tooltip />
                        <Line type="monotone" dataKey="avgRisk" stroke="#3b82f6" strokeWidth={4} dot={false} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </>
          )}

          {activeTab === "Analytics" && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
               <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm h-[400px]">
                  <h3 className="text-xl font-black mb-6">Distribution by Category</h3>
                  <ResponsiveContainer width="100%" height="80%">
                    <PieChart>
                      <Pie data={MOCK_CATEGORIES} innerRadius={80} outerRadius={110} paddingAngle={5} dataKey="value">
                        {MOCK_CATEGORIES.map((_, index) => <Cell key={index} fill={COLORS[index % COLORS.length]} />)}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
               </div>
               <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm h-[400px]">
                  <h3 className="text-xl font-black mb-6">Aggregate Risk Score History</h3>
                  <ResponsiveContainer width="100%" height="80%">
                    <LineChart data={MOCK_TREND}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis dataKey="date" tick={{fontSize: 10}} dy={10} />
                      <YAxis tick={{fontSize: 10}} />
                      <Tooltip />
                      <Line type="step" dataKey="avgRisk" stroke="#3b82f6" strokeWidth={3} />
                    </LineChart>
                  </ResponsiveContainer>
               </div>
            </div>
          )}

          {activeTab === "Alerts" && (
            <div className="space-y-4 max-w-4xl">
              {MOCK_ALERTS.map((alert) => (
                <div key={alert.id} className="bg-white rounded-2xl p-6 border border-slate-200 flex items-center justify-between shadow-sm">
                  <div className="flex items-center gap-4">
                    <div className={`p-3 rounded-xl ${alert.severity === 'CRITICAL' ? 'bg-red-50 text-red-500' : 'bg-blue-50 text-blue-500'}`}>
                      <ShieldAlert size={24} />
                    </div>
                    <div>
                      <h4 className="font-black text-lg">{alert.message}</h4>
                      <p className="text-sm text-slate-500 font-medium">Timestamp: {new Date(alert.createdAt).toLocaleString()}</p>
                    </div>
                  </div>
                  <button className="flex items-center gap-2 text-blue-600 font-bold text-sm hover:underline">
                    <CheckCircle size={18} />
                    Resolve Issue
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

function StatCard({ title, value, icon: Icon, color, trend }: any) {
  const colorMap: any = {
    blue: "text-blue-600 bg-blue-50 shadow-blue-100",
    red: "text-red-600 bg-red-50 shadow-red-100",
    green: "text-green-600 bg-green-50 shadow-green-100",
    orange: "text-orange-600 bg-orange-50 shadow-orange-100",
  };

  return (
    <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm flex flex-col justify-between group hover:border-blue-200 transition-all cursor-default">
      <div className="flex justify-between items-start mb-4">
        <div className={`p-3 rounded-2xl ${colorMap[color]} shadow-lg transition-transform group-hover:scale-110`}>
          <Icon size={24} />
        </div>
        <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Live</span>
      </div>
      <div>
        <p className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-1">{title}</p>
        <h3 className="text-3xl font-black text-slate-900 tracking-tighter">{value}</h3>
        <p className="text-xs text-blue-600 font-black mt-2 tracking-tight">{trend}</p>
      </div>
    </div>
  );
}
